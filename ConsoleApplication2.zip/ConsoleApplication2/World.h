#pragma once
void world(int x, int y);