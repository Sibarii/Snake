#pragma once

bool snakeDie();
int snake(int x, int y);
int move(/*const char* prompt*/ );
