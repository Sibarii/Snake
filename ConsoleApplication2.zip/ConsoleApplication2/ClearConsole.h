#pragma once
void ClearConsole();


