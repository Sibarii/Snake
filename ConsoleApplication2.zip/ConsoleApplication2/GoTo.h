#pragma once
void gotoXY(int x, int y);
